'use strict';
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res) {
    //calculate function takes 3 parameters method ,x,y

    function calculate(method, x, y) {
        if (method = 'add') {
            console.log("Sample output:"(x + y));

        }
        else if (method = 'subtract') {
            console.log("Sample output:"(x - y));

        }
        else if (method = 'divide') {
            console.log("Sample output:"(x / y));

        }
        else if (method = 'multiply') {
            console.log("Sample output:"(x * y));

        }
        else {
            console.log(" add a  valid parameter to perform any function");
        }


    }
    console.log(req.query);
    console.log(req.query.method);
    res.render('index', { title: 'Express' });
});

module.exports = router;
